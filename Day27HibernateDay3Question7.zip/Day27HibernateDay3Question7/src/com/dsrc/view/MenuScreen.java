package com.dsrc.view;

import java.util.Scanner;

import com.dsrc.service.CustomerController;
import com.dsrc.service.ProductController;
import com.dsrc.service.StaffController;

public class MenuScreen
{

	public int showMenu() {
	
		// Show the Menu Here..
		Scanner sc=new Scanner(System.in);
		System.out.println("showMenu.. output");
		System.out.println("---------------------");
		System.out.println("Select Your Option");
		System.out.println("1. Product");
		System.out.println("2. Sales");
		System.out.println("3. Staff");
		System.out.println("4. Customer");
		System.out.println("Enter your Choice :");
		int menu=sc.nextInt();
		switch(menu)
		{
		case 1:
			ProductController pc=new ProductController();
			pc.productManager();
			break;
				
		case 3:
			StaffController sc1= new StaffController();
			sc1.productManager();
			break;
			
		case 4:
			CustomerController cc=new CustomerController();
			cc.customerManager();
			break;
			
		}
		return 0;
	}

}

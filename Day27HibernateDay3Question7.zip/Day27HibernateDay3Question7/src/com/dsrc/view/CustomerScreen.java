package com.dsrc.view;

import java.util.Scanner;

import com.dsrc.model.Customer;
import com.dsrc.model.Staff;
import com.dsrc.service.DataValidator;

public class CustomerScreen 
{
	public int showCustomerScreen()
	{
		// Add the product Menu..
		Scanner sc=new Scanner(System.in);
		System.out.println("CUSTOMER MENU");
		System.out.println("1. New Customer");
		System.out.println("2. Edit Customer");
		System.out.println("3. Delete Customer");
		System.out.println("4. Exit");
		
		System.out.println("Enter Your Choice");
		int cus=sc.nextInt();
		switch(cus)
		{
		case 1:
			System.out.println("Enter CustomerID:");
			int cusid=sc.nextInt();
			System.out.println(" Enter CustomerName:");
			String cusname=sc.next();
			System.out.println("Enter Email:");
			String cusmail=sc.next();
			System.out.println("Enter Mobile");
			int cusmobile=sc.nextInt();
			
			Customer customer= new Customer(cusid, cusname, cusmail, cusmobile);
			DataValidator dv=new DataValidator();
			dv.validateCustomer(customer);
			break;
		
		case 2:
			System.out.println("Enter CustomerID:");
			int cusid1=sc.nextInt();
			System.out.println(" Enter New CustomerName:");
			String cusname1=sc.next();
			System.out.println("Enter New Email:");
			String cusmail1=sc.next();
			System.out.println("Enter New Mobile");
			int cusmobile1=sc.nextInt();
			
			Customer customer1= new Customer(cusid1, cusname1, cusmail1, cusmobile1);
			DataValidator dv1=new DataValidator();
			dv1.editCustomer(customer1);
			break;
			
		case 3:
			System.out.println("Enter CustomerID:");
			int cusid2=sc.nextInt();
			
			Customer c=new Customer();
			c.setCustomerid(cusid2);
			DataValidator dv2= new DataValidator();
			dv2.deleteCustomer(c);
			break;
			
		}
		
		return 0;
	}
}

	
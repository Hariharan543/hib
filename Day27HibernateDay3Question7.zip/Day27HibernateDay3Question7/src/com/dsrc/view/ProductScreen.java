package com.dsrc.view;
import java.util.List;
import java.util.Scanner;

import com.dsrc.dao.HibernateUtil;
import com.dsrc.model.Product;
import com.dsrc.service.DataValidator;
import com.dsrc.service.ProductController;
public class ProductScreen 
{
	public int showProductScreen()
	{
			// Add the product Menu..
		Scanner sc=new Scanner(System.in);
		
		System.out.println("PRODUCT MENU");
		System.out.println("--------------");
		System.out.println("1. New Product");
		System.out.println("2. Edit Product");
		System.out.println("3. Delete Product");
		System.out.println("4. List Product");
		System.out.println("5. Search Product");
		System.out.println("6. Exit");
		
		System.out.println("Enter Your Choice:");
		
		int prod=sc.nextInt();
		switch(prod)
		{
		case 1:
			System.out.println("Enter Product ID: ");
			int productid=sc.nextInt();
			System.out.println("Enter Product Name: ");
			String productname=sc.next();
			System.out.println("Enter Product Price: ");
			int productprice=sc.nextInt();
			
			Product product=new Product(productid, productname, productprice);
			DataValidator dv=new DataValidator();
			dv.validateProduct(product);
			
		case 2:
			System.out.println("Enter Product ID: ");
			int productid1=sc.nextInt();
		
			System.out.println("New Product Name: ");
			String productname1=sc.next();
			System.out.println("New Product Price: ");
			int productprice1=sc.nextInt();
			
			Product product1=new Product(productid1, productname1, productprice1);
			DataValidator dv1=new DataValidator();
			dv1.updateProduct(product1);
			
		case 3:
			System.out.println("Enter Product ID: ");
			int productid3=sc.nextInt();
			
			Product product3=new Product();
			DataValidator dv3=new DataValidator();
			dv3.deleteProduct(product3);
			
		case 4:
			HibernateUtil hu= new HibernateUtil();
			List l=hu.selectAllProducts();
			Product p;
			System.out.println("--------------------------------------------");
			System.out.format("%-15s %-15s %-15s %n", "Productid", "productname", "Productprice");
			System.out.println("----------------------------------------------");
			for(java.util.Iterator i=l.iterator();i.hasNext();)
			{
				p=(Product) i.next();
				System.out.format("%-15s %-15s %-15s %n", p.getProductid(), p.getProductname(), p.getProductprice());
			}
	
		
		case 5:
			
			System.out.println("Enter the Search Criteria");
			System.out.println("1. By ProductID");
			System.out.println("2. By Name");
			System.out.println("3. By Price Range");
			int select=sc.nextInt();
			switch(select)
			{
			case 1 :
			
				System.out.println("Enter Product ID :");
				int id1=sc.nextInt();
				boolean res1=new HibernateUtil().searchByID(id1);
				ProductScreen ps= new ProductScreen();
				ps.showProductScreen();
				break;
			
			case 2:
				System.out.println("Enter Product Name:");
				String name=sc.next();
				boolean res2= new HibernateUtil().searchByname(name);
				ProductScreen ps1= new ProductScreen();
				ps1.showProductScreen();
				break;
			
			case 3:
				System.out.println("Enter From Price:");
				int fromPrice=sc.nextInt();
				System.out.println("Enter To Price:");
				int toPrice=sc.nextInt();
				boolean res3=new HibernateUtil().searchByrange(fromPrice, toPrice);
				ProductScreen ps2= new ProductScreen();
				ps2.showProductScreen();
				break;
			}
					
		}
		
		return prod;
	}
}

	
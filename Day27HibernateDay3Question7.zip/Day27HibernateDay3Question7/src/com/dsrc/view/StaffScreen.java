package com.dsrc.view;

import java.util.Scanner;

import com.dsrc.model.Staff;
import com.dsrc.service.DataValidator;

public class StaffScreen 
{
	public int showStaffScreen()
	{
		// Add the product Menu..
		// Add the product Menu..
		Scanner sc=new Scanner(System.in);
		System.out.println("STAFF MENU");
		System.out.println("----------");
	
		System.out.println("1. New Staff");
		System.out.println("2. Edit Staff");
		System.out.println("3. Delete Staff");
		System.out.println("4. Exit");
		System.out.println("Enter your Choice : ");
		int menu=sc.nextInt();
		switch(menu)
		{
		case 1:
			System.out.println(" Enter StaffID: ");
			int sid=sc.nextInt();
			System.out.println("Enter Staff Name: ");
			String sname=sc.next();
			System.out.println("Enter Salary");
			int ssalary=sc.nextInt();
			
			Staff staff=new Staff(sid, sname, ssalary);
			DataValidator dv=new DataValidator();
			dv.validateStaff(staff);
			
		case 2:
			System.out.println(" Enter StaffID: ");
			int sid2=sc.nextInt();
			System.out.println("Enter Staff Name: ");
			String sname2=sc.next();
			System.out.println("Enter Salary");
			int ssalary2=sc.nextInt();
			
			Staff staff2=new Staff(sid2, sname2, ssalary2);
			DataValidator dv2=new DataValidator();
			dv2.updateStaff(staff2);
			break;
			
		case 3:
			System.out.println("Enter StaffId:");
			int sid1=sc.nextInt();
			
			Staff staff1=new Staff();
			staff1.setStaffid(sid1);
			DataValidator dv1= new DataValidator();
			dv1.deleteStaff(staff1);
			break;
		

		}
		return menu;
	}
}

package com.dsrc.service;

import com.dsrc.dao.HibernateUtil;
import com.dsrc.model.Customer;
import com.dsrc.model.Product;
import com.dsrc.model.Staff;
import com.dsrc.view.CustomerScreen;
import com.dsrc.view.ProductScreen;
import com.dsrc.view.StaffScreen;

public class DataValidator 
{
	public boolean validateProduct(Product product)
	{
		// Code to call DAO..
		HibernateUtil hu=new HibernateUtil();
		boolean res=hu.saveProduct(product);
		if(res)
		{
			System.out.println("Product Added Successfully");
			ProductScreen ps=new ProductScreen();
			ps.showProductScreen();
		}
	
		return res;
		
	}
	
	public boolean validateStaff(Staff staff)
	{
		// Code to call DAO..
		HibernateUtil hu=new HibernateUtil();
		boolean res=hu.saveStaff(staff);
		if(res)
		{
			System.out.println("Staff Added Successfully");
			StaffScreen ss=new StaffScreen();
			ss.showStaffScreen();
		}
	
		return res;
		
	}
	
	
	public boolean updateProduct(Product product)
	{
		//Code to call DAO.
				HibernateUtil hu=new HibernateUtil();
				boolean res=hu.updateProduct(product);
				try{
				if(res)
				{
					System.out.println("Product Information Updated..");
					ProductScreen ps=new ProductScreen();
					ps.showProductScreen();
				}
				}
				catch(Exception e)
				{
					System.out.println("invalid id");
					ProductScreen ps=new ProductScreen();
					ps.showProductScreen();
				}
			
				return res;

	}

	public boolean updateStaff(Staff staff)
	{
		HibernateUtil hu=new HibernateUtil();
		boolean res=hu.updateStaff(staff);
		if(res)
		{
			System.out.println("Staff updated Successfully");
			StaffScreen ss=new StaffScreen();
			ss.showStaffScreen();
		}
	
		return res;
	}
	
	public boolean deleteStaff(Staff staff)
	{
		HibernateUtil hu=new HibernateUtil();
		boolean res=hu.deleteStaff(staff);
		if(res)
		{
			System.out.println("Staff deleted Successfully");
			StaffScreen ss=new StaffScreen();
			ss.showStaffScreen();
		}
		return res;
		
	}
	
	public boolean deleteProduct(Product product)
	{
		HibernateUtil hu=new HibernateUtil();
		boolean res=hu.deleteProduct(product);
		if(res)
		{
		System.out.println("Product Deleted Successfully");
		ProductScreen p=new ProductScreen();
		p.showProductScreen();	
		}
		else{
			
		System.out.println("INVALID ID");
		ProductScreen p=new ProductScreen();
		p.showProductScreen();
	}
		return res;
	
	}
	
	public boolean validateCustomer(Customer customer)
	{
		// Code to call DAO..
		HibernateUtil hu=new HibernateUtil();
		boolean res=hu.saveCustomer(customer);
		if(res)
		{
			System.out.println("Customer added Successfully");
			CustomerScreen ss=new CustomerScreen();
			ss.showCustomerScreen();
		}
		return res;
	}
	public boolean editCustomer(Customer customer)
	{
		HibernateUtil hu=new HibernateUtil();
		boolean res=hu.editCustomer(customer);
		if(res)
		{
			System.out.println("customer updated Successfully");
			CustomerScreen ss=new CustomerScreen();
			ss.showCustomerScreen();
		}
	
		return res;
	}
	
	public boolean deleteCustomer(Customer customer)
	{
		HibernateUtil hu=new HibernateUtil();
		boolean res=hu.deleteCustomer(customer);
		if(res)
		{
			System.out.println("Customer deleted Successfully");
			CustomerScreen ss=new CustomerScreen();
			ss.showCustomerScreen();
		}
		return res;
		
	}
}

package com.dsrc.service;

import com.dsrc.view.StaffScreen;

public class StaffController 
{
	public int productManager()
	{

		StaffScreen ss=new StaffScreen();
		ss.showStaffScreen();
		return 0;
	}
}

package com.dsrc.model;
import javax.persistence.*;

@Entity
@Table(name="Customer")
public class Customer {
	@Id
	@Column(name="CustomerID")
	private int customerid;
	
	@Column(name="CustomerName")
	private String customername;
	
	@Column(name="CustomerEmail")
	private String customeremail;
	
	@Column(name="CustomerMobile")
	private int customermobile;
	
	public Customer(){
				
	}
	
	public Customer( int customerid, String customername, String customeremail, int customermobile)
	{
		this.customerid=customerid;
		this.customername=customername;
		this.customeremail=customeremail;
		this.customermobile=customermobile;
		
	}

	public int getCustomerid() {
		return customerid;
	}

	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}

	public String getCustomername() {
		return customername;
	}

	public void setCustomername(String customername) {
		this.customername = customername;
	}

	public String getCustomeremail() {
		return customeremail;
	}

	public void setCustomeremail(String customeremail) {
		this.customeremail = customeremail;
	}

	public int getCustomermobile() {
		return customermobile;
	}

	public void setCustomermobile(int customermobile) {
		this.customermobile = customermobile;
	}
}

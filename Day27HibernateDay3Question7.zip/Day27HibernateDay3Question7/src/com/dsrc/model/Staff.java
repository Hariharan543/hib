package com.dsrc.model;

import javax.persistence.*;
@Entity
@Table(name="Staff")

public class Staff {
	// Create variables and getters and setters..
	@Id
	@Column(name="staffid")
	private int staffid;
	
	@Column(name="staffname")
	private String staffname;
	
	@Column(name="staffsalary")
	private int staffsalary;
	
	public Staff(){
		
	}
	
	public Staff(int staffid, String staffname, int staffsalary)
	{
		this.staffid=staffid;
		this.staffname=staffname;
		this.staffsalary=staffsalary;	
	}

	public int getStaffid() {
		return staffid;
	}

	public void setStaffid(int staffid) {
		this.staffid = staffid;
	}

	public String getStaffname() {
		return staffname;
	}

	public void setStaffname(String staffname) {
		this.staffname = staffname;
	}

	public int getStaffsalary() {
		return staffsalary;
	}

	public void setStaffsalary(int staffsalary) {
		this.staffsalary = staffsalary;
	}
}